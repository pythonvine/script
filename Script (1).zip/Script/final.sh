#!/bin/bash
pg_user="postgres"
node1="nr-main-postgresql-01"
node2="nr-main-postgresql-02"
node3="nr-bkp-postgresql-01"
node4="nr-bkp-postgresql-02"

# Run the `repmgr` command and save its output to a file
sudo -u $pg_user repmgr -f /etc/postgresql/15/main/repmgr.conf cluster event --event=repmgrd_failover_promote > repmgr_output.txt

python3 failover.py

file_path="nodes.txt"

file_content=$(cat "$file_path")

if [[ "$file_content" == "$node1" ]]; then
    # Run the commands on node2,node3 and node4
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node2:/opt
    ssh root@$node2 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node3:/opt
    ssh root@$node3 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node4:/opt
    ssh root@$node4 '/opt/standby.sh'
elif [[ "$file_content" == "$node2" ]]; then
    # Run the commands on node1,node3 and node4
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node1:/opt
    ssh root@$node1 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node3:/opt
    ssh root@$node3 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node4:/opt
    ssh root@$node4 '/opt/standby.sh'
elif [[ "$file_content" == "$node3" ]]; then
    # Run the commands on node1 and node2
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node1:/opt
    ssh root@$node1 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node2:/opt
    ssh root@$node2 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node4:/opt
    ssh root@$node4 '/opt/standby.sh'
elif [[ "$file_content" == "$node4" ]]; then
    # Run the commands on node1 and node2
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node1:/opt
    ssh root@$node1 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node2:/opt
    ssh root@$node2 '/opt/standby.sh'
    sudo scp /opt/standby.sh /opt/nodes.txt root@$node3:/opt
    ssh root@$node3 '/opt/standby.sh'
fi
