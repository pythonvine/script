import pandas as  pd
import numpy as np
from datetime import datetime, timedelta
import os
import sys



file_path = "repmgr_output.txt"  

df = pd.read_csv(file_path, sep='|', skipinitialspace=True)

df.columns = df.columns.str.strip()

df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)



filtered_df = df[df['Event']=='repmgrd_failover_promote']
filtered_df['Timestamp'] = pd.to_datetime(filtered_df['Timestamp'])
filtered_df = filtered_df.sort_values(by='Timestamp', ascending=True)



def create_or_replace_file(file_path, string_list):
    try:
        with open(file_path, 'w') as file:
            for string in string_list:
                file.write(string + '\n')
    except Exception as e:
        print(f"An error occurred: {e}")
        
        
        
        
    
file_name = 'failover_last_time.csv'
last_timestamp = filtered_df['Timestamp'].iloc[-1]
last_node = filtered_df[filtered_df['Timestamp']==last_timestamp]['Name']
def save_timestamp_to_csv(file_name, last_timestamp):
    if not os.path.exists(file_name):
        # If the file doesn't exist, create a new DataFrame
        data = {'Timestamp': [last_timestamp]}
        df = pd.DataFrame(data)

        df.to_csv(file_name, index=False, header=False)  
        
        file_path = "nodes.txt"
        nodes = last_node
        create_or_replace_file(file_path, nodes)
        
        sys.exit()
    else:
        pass

save_timestamp_to_csv(file_name, last_timestamp)




csv_file_check = 'failover_last_time.csv'

if os.path.exists(csv_file_check):
    df = pd.read_csv(csv_file_check, header=None, names=['timestamp'])

    df['timestamp'] = pd.to_datetime(df['timestamp'], format='%Y-%m-%d %H:%M:%S')

    final_df = filtered_df[filtered_df['Timestamp'] > df['timestamp'].iloc[0]]
else:
    print("no new data")
    
    
    
    
last_timestamp = filtered_df['Timestamp'].iloc[-1]



def save_timestamp_to_csv(file_name):
    data = {'Timestamp': [last_timestamp]}
    df = pd.DataFrame(data)

    df.to_csv(file_name, index=False, header=False)

file_name = 'failover_last_time.csv'

save_timestamp_to_csv(file_name)



def create_or_replace_file(file_path, string_list):
    try:
        with open(file_path, 'w') as file:
            for string in string_list:
                file.write(string + '\n')
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage:
file_path = "nodes.txt"
nodes = list(final_df['Name'])
create_or_replace_file(file_path, nodes)
