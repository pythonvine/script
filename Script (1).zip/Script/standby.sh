#!/bin/bash
# Specify the unprivileged user who owns the PostgreSQL data directory
pg_user="postgres"
host=$(</opt/nodes.txt)
echo "The host variable contains: $host"

# Stop PostgreSQL
sudo systemctl stop postgresql
sleep 5
# Switch to the PostgreSQL user and clone the standby
sudo -u $pg_user repmgr -h $host -U repmgr -d repmgr -f /etc/postgresql/15/main/repmgr.conf standby clone -F

# Restart PostgreSQL
sudo systemctl restart postgresql
sleep 5
# Switch to the PostgreSQL user and register the standby
sudo -u $pg_user repmgr -f /etc/postgresql/15/main/repmgr.conf standby register -F

sudo -u $pg_user repmgr -f /etc/postgresql/15/main/repmgr.conf cluster show
