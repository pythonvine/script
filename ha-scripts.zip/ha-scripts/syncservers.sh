#!/bin/bash
#rsync -rlptgoDq /opt/librenms/rrd/* root@IPADDRESS:/opt/librenms/rrd/*
rsync -rlptgoDq /opt/lampstack/apache2/htdocs/* root@IPADDRESS:/opt/lampstack/apache2/htdocs/*
