#!/bin/bash
#watch -n 30 /usr/bin/ha-script-primary &
while true; do /usr/bin/ha-script-primary ;date ; sleep 30; done
