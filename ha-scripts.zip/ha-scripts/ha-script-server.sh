#!/bin/bash
NOWTIME=$(date +%c)
DETECTIP=$(ifconfig | grep -A 1 ens33 |head -2 | tail -1 | cut -d ':' -f 2 | awk {'print $2'})
#
VIRTUALIP="10.10.10.29"
PRIMARYIP="10.10.10.27"
SECONDARYIP="10.10.10.28"
NETMASK="255.255.255.0"
#SWITCHIP=""
TYPE="10"
#
arp -d $VIRTUALIP > /dev/null 2>&1
ip -s -s neigh flush all > /dev/null 2>&1
#
if [ "$DETECTIP" == "$PRIMARYIP" ]; then
DETECTIP=$SECONDARYIP
else
DETECTIP=$PRIMARYIP
fi
echo $DETECTIP
servers=( $DETECTIP )
for i in "${servers[@]}"
do
  fping -c10 $i > /dev/null 2>&1
    if [ $? -ne 1 ]; then
        echo "Server Heartbeat is OK"
        ip link add link ens33 address 00:0c:29:06:4f:21 $TYPE type macvlan > /dev/null 2>&1
        ifconfig $TYPE $VIRTUALIP netmask $NETMASK up > /dev/null 2>&1 
        sudo sshpass -p "Infra@2603##" ssh -p20213 -o StrictHostKeyChecking=no support@10.10.10.28 sudo ifconfig $TYPE $VIRTUALIP netmask $NETMASK down
        sudo sshpass -p "Infra@2603##" ssh -p20213 -o StrictHostKeyChecking=no support@10.10.10.28 sudo arp -d $VIRTUALIP
        sudo sshpass -p "Infra@2603##" ssh -p20213 -o StrictHostKeyChecking=no support@10.10.10.28 sudo ip -s -s neigh flush all
        echo "$NOWTIME Virtual IP Assigned to Primary Server" >> /opt/virtual-ip-logs
        /usr/bin/syncservers
else
        echo "Server Heartbeat ERROR"
    fi
done
